package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    private final ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        ListView menuListView = findViewById(R.id.menuListView);
        Button orderButton = findViewById(R.id.orderButton);


        String[] menuItems = {"Pizza", "Hamburger", "Lahmacun", "Döner", "Tatlı"};


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, menuItems);
        menuListView.setAdapter(adapter);
        menuListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


        menuListView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            String selectedItem = menuItems[position];
            if (selectedItems.contains(selectedItem)) {
                selectedItems.remove(selectedItem);
            } else {
                selectedItems.add(selectedItem);
            }
        });


        orderButton.setOnClickListener(v -> {
            if (selectedItems.isEmpty()) {
                Toast.makeText(MenuActivity.this, "Lütfen en az bir yemek seçin!", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(MenuActivity.this, OrderActivity.class);
                intent.putStringArrayListExtra("selectedItems", selectedItems);
                startActivity(intent);
            }
        });
    }
}
